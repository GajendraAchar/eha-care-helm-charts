import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'
import styles from '../src/styles/Home.module.css'

const Home: NextPage = () => {

  return (
    <div className={styles.container}>
      <Head>
       
      </Head>

      <main className={styles.main}>

       <div><h1 style={{ fontSize: 40}}>Welcome to EHA CARE</h1></div>
       <h2>Hello World!!!</h2>
      </main>
    </div>
  )
}

export default Home
